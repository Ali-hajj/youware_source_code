// Auto-import of sample events has been retired to ensure the app is fully database-driven.
// This module remains as a stub to avoid breaking dynamic imports, but it now returns an empty list.

export function getAutoImportEvents() {
  return [];
}
